# I.D.T. Tool Inventory — Full Android Project

Native Android app for I.D.T. Steelworks and Engineering.

## Included
- Black / neon green / neon orange branding
- Dashboard with total items, estimated value, assigned/unassigned counts and totals by type
- New item form: item number, make, model, type, description, serial, price, item photo and employee assignment
- Employee database with employee ID and ID photo
- Search / lookup by item number, serial, make, model, employee and type
- Locked employee and I.D.T. signature capture on each item
- Individual employee profiles showing every assigned tool and total value
- Separate PDF allocation report for each employee, including employee name, ID photo, assigned tool list, tool photos, values and signatures
- Local offline storage
- JSON backup / share

## GitHub Actions
The included workflow builds a debug APK and uploads it as an Actions artifact. It does not depend on a ZIP-inside-a-ZIP extraction step.
