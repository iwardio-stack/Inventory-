# I.D.T. Tool Inventory

A new standalone Android project based on the supplied reference design.

## Included
- Black / neon green / neon orange IDT branding
- Home dashboard with total items, estimated value, assigned/unassigned and totals by type
- New Item flow: item details -> employee & photos -> signatures -> save
- Employee ID photos and tool photos
- Locked employee and supervisor signature blocks
- Offline local storage
- Item lookup/search
- Employee list and assigned tool counts
- Individual item PDF
- Employee tool assignment PDF
- Complete inventory PDF
- Backup sharing

## GitHub build
Upload this project as the repository contents. The included `.github/workflows/build-apk.yml` builds the debug APK and uploads it as an Actions artifact.
