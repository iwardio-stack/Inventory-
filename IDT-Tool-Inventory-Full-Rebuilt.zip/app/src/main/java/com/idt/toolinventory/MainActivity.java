package com.idt.toolinventory;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.*;
import android.view.View;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    static final int FILE_PICK=42;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA},9);
        web=new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=p.createIntent();
                try{startActivityForResult(i,FILE_PICK);}catch(Exception e){fileCallback=null;return false;}
                return true;
            }
        });
        web.addJavascriptInterface(new AndroidBridge(),"Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==FILE_PICK && fileCallback!=null){
            Uri[] out=WebChromeClient.FileChooserParams.parseResult(c,d);
            fileCallback.onReceiveValue(out); fileCallback=null;
        }
    }

    class AndroidBridge {
        @JavascriptInterface public void createPdf(String json){
            try{
                JSONObject o=new JSONObject(json);
                File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"IDT-Reports");
                if(!dir.exists()) dir.mkdirs();
                String kind=o.optString("kind","report");
                String stamp=String.valueOf(System.currentTimeMillis());
                File pdf=new File(dir,"IDT-"+kind+"-"+stamp+".pdf");
                PdfDocument doc=new PdfDocument();
                if("item".equals(kind)) makeItem(doc,o);
                else if("employee".equals(kind)) makeEmployee(doc,o);
                else makeAll(doc,o);
                FileOutputStream fos=new FileOutputStream(pdf); doc.writeTo(fos); fos.close(); doc.close();
                runOnUiThread(()->sharePdf(pdf));
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF error: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
    }

    Paint p(int color,float size,boolean bold){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);return p;}
    void header(Canvas c, JSONObject o){
        c.drawColor(Color.WHITE);
        Paint black=p(Color.BLACK,10,false), green=p(Color.rgb(90,210,0),22,true), orange=p(Color.rgb(255,101,0),10,true);
        c.drawRect(0,0,595,86,p(Color.BLACK,1,false));
        c.drawText("I.D.T.",22,30,green); c.drawText("STEELWORKS AND ENGINEERING",22,54,green);
        c.drawText("WELDING • FABRICATION • INSTALLATION",22,73,orange);
        c.drawText(o.optString("email","iwardio@idtsteelwork.co.za"),390,28,black);
        c.drawText("Western Cape",390,44,black);
        c.drawLine(0,90,595,90,p(Color.BLACK,2,false));
    }
    void title(Canvas c,String s,float y){
        c.drawRect(18,y-22,577,y+5,p(Color.BLACK,1,false));
        c.drawText(s,25,y-2,p(Color.WHITE,13,true));
    }
    void txt(Canvas c,String s,float x,float y,float max,float size,boolean bold){
        Paint q=p(Color.DKGRAY,size,bold); String[] words=s.split(" "); String line="";
        float yy=y;
        for(String w:words){String test=line.isEmpty()?w:line+" "+w;if(q.measureText(test)>max && !line.isEmpty()){c.drawText(line,x,yy,q);yy+=size+3;line=w;}else line=test;}
        if(!line.isEmpty())c.drawText(line,x,yy,q);
    }
    Bitmap b64(String s){try{if(s==null||s.isEmpty())return null;int i=s.indexOf(',');if(i>=0)s=s.substring(i+1);byte[] b=android.util.Base64.decode(s,android.util.Base64.DEFAULT);return BitmapFactory.decodeByteArray(b,0,b.length);}catch(Exception e){return null;}}
    void img(Canvas c,Bitmap b,float x,float y,float w,float h){if(b==null)return;Paint q=new Paint(Paint.ANTI_ALIAS_FLAG);RectF r=new RectF(x,y,x+w,y+h);c.drawBitmap(b,null,r,q);}
    PdfDocument.Page page(PdfDocument d,int n){return d.startPage(new PdfDocument.PageInfo.Builder(595,842,n).create());}

    void makeItem(PdfDocument d,JSONObject o)throws Exception{
        JSONObject i=o.getJSONObject("item"), e=o.optJSONObject("employee");
        PdfDocument.Page pg=page(d,1);Canvas c=pg.getCanvas();header(c,o);
        title(c,"TOOL INVENTORY REPORT - INDIVIDUAL ITEM",118);
        txt(c,"Item Number: "+i.optString("number"),30,145,230,11,true);
        txt(c,"Make: "+i.optString("make"),30,165,230,11,true);
        txt(c,"Model Number: "+i.optString("model"),30,185,230,11,true);
        txt(c,"Type: "+i.optString("type"),30,205,230,11,true);
        txt(c,"Description: "+i.optString("desc"),30,225,230,11,false);
        txt(c,"Serial Number: "+i.optString("serial"),30,260,230,11,true);
        txt(c,"Estimated Value: R "+String.format(Locale.US,"%,.2f",i.optDouble("price")),30,280,230,11,true);
        img(c,b64(i.optString("photo")),285,142,270,175);
        title(c,"ASSIGNED TO",350);
        if(e!=null){img(c,b64(e.optString("photo")),30,365,85,85);txt(c,e.optString("name"),130,390,400,13,true);txt(c,e.optString("empNo")+" • "+e.optString("role"),130,410,400,11,false);}
        else txt(c,"UNASSIGNED",30,390,400,13,true);
        title(c,"SIGNATURES",480);
        img(c,b64(i.optString("sigEmployee")),30,500,250,105); img(c,b64(i.optString("sigSupervisor")),310,500,250,105);
        txt(c,"Employee Signature",30,625,250,10,true);txt(c,"Supervisor Signature",310,625,250,10,true);
        title(c,"NOTES",660);txt(c,i.optString("notes",""),30,690,525,11,false);
        d.finishPage(pg);
    }

    void makeEmployee(PdfDocument d,JSONObject o)throws Exception{
        JSONObject e=o.getJSONObject("employee");JSONArray a=o.getJSONArray("items");
        PdfDocument.Page pg=page(d,1);Canvas c=pg.getCanvas();header(c,o);title(c,"EMPLOYEE TOOL ASSIGNMENT REPORT",118);
        img(c,b64(e.optString("photo")),25,135,85,85);txt(c,e.optString("name"),125,155,300,14,true);txt(c,e.optString("empNo")+" • "+e.optString("role"),125,176,300,11,false);
        double total=0;for(int x=0;x<a.length();x++)total+=a.getJSONObject(x).optDouble("price");
        txt(c,"Total Items Assigned: "+a.length(),385,155,180,11,true);txt(c,"Total Estimated Value: R "+String.format(Locale.US,"%,.2f",total),385,176,180,11,true);
        title(c,"ASSIGNED TOOLS",245);
        float y=280;
        for(int x=0;x<a.length();x++){
            if(y>755){d.finishPage(pg);pg=page(d,pg.getInfo().getPageNumber()+1);c=pg.getCanvas();header(c,o);title(c,"EMPLOYEE TOOL ASSIGNMENT REPORT — CONTINUED",118);y=155;}
            JSONObject i=a.getJSONObject(x);img(c,b64(i.optString("photo")),25,y-18,65,55);
            txt(c,(x+1)+". "+i.optString("number"),100,y,120,10,true);txt(c,i.optString("make")+" "+i.optString("model"),225,y,140,10,false);
            txt(c,i.optString("type"),365,y,100,9,false);txt(c,"R "+String.format(Locale.US,"%,.2f",i.optDouble("price")),465,y,100,9,true);
            c.drawLine(25,y+45,570,y+45,p(0xffdddddd,1,false));y+=62;
        }
        if(y>700){d.finishPage(pg);pg=page(d,pg.getInfo().getPageNumber()+1);c=pg.getCanvas();header(c,o);title(c,"SIGNATURES",150);y=190;}
        else title(c,"SIGNATURES",y+20);
        JSONObject last=a.length()>0?a.getJSONObject(0):new JSONObject();
        img(c,b64(last.optString("sigEmployee")),30,y+35,250,105);img(c,b64(last.optString("sigSupervisor")),310,y+35,250,105);
        d.finishPage(pg);
    }

    void makeAll(PdfDocument d,JSONObject o)throws Exception{
        JSONArray a=o.getJSONArray("items");PdfDocument.Page pg=page(d,1);Canvas c=pg.getCanvas();header(c,o);title(c,"COMPLETE TOOL INVENTORY REPORT",118);
        float y=155;double total=0;
        for(int x=0;x<a.length();x++){
            JSONObject i=a.getJSONObject(x);total+=i.optDouble("price");
            if(y>770){d.finishPage(pg);pg=page(d,pg.getInfo().getPageNumber()+1);c=pg.getCanvas();header(c,o);title(c,"COMPLETE TOOL INVENTORY REPORT — CONTINUED",118);y=155;}
            img(c,b64(i.optString("photo")),20,y-18,65,48);
            txt(c,i.optString("number"),95,y,80,9,true);txt(c,i.optString("make"),175,y,80,9,false);txt(c,i.optString("model"),255,y,80,9,false);txt(c,i.optString("type"),335,y,90,9,false);txt(c,i.optString("serial"),425,y,80,9,false);txt(c,"R "+String.format(Locale.US,"%,.2f",i.optDouble("price")),500,y,75,8,true);
            c.drawLine(20,y+36,575,y+36,p(0xffdddddd,1,false));y+=50;
        }
        txt(c,"TOTAL ESTIMATED VALUE: R "+String.format(Locale.US,"%,.2f",total),340,810,230,12,true);d.finishPage(pg);
    }

    void sharePdf(File f){
        try{
            Uri u=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".provider",f);
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share IDT PDF"));
        }catch(Exception e){Toast.makeText(this,"PDF saved: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show();}
    }
}
