# I.D.T. Tool Inventory v2

Full offline inventory app matching the supplied reference layout and workflow.

Features:
- IDT black / neon green / neon orange interface
- Dashboard totals and value by type
- New Item workflow
- Employee profiles with ID photos
- Tool photos
- Locked employee and supervisor signatures
- Item lookup
- Employee tool lists
- Individual item PDF
- Employee assignment PDF
- Complete inventory PDF
- Offline local storage
- JSON backup / restore
- PDF sharing

Company: I.D.T. STEELWORKS AND ENGINEERING
Email: iwardio@idtsteelwork.co.za
