# I.D.T. Tool Inventory App

Native Android app for I.D.T. STEELWORKS AND ENGINEERING. Designed around the approved mock-up: black industrial UI, neon green primary actions, neon orange section accents, dashboard, item entry, employee assignment, locked signatures, item lookup, employee reports, PDF export and sharing.

## Easy creation
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Let Gradle sync.
3. Run **app** on an Android phone/emulator.
4. Or push this folder to GitHub. The included workflow builds a debug APK automatically.

The project intentionally uses Android framework APIs for storage, PDF generation and sharing, so there are no third-party app libraries to install.

## Features
- Offline SQLite inventory database.
- Item number, make, model, type, description, serial number, price estimate.
- Employee records with ID number and ID photo.
- Tool photo from camera or gallery.
- Locked employee and supervisor signatures.
- Dashboard total estimated inventory value and item/type totals.
- Search by item number, make, model, serial number or employee.
- Individual item PDF.
- Separate PDF report for every employee listing all assigned tools and employee total value.
- Complete inventory PDF.
- WhatsApp/general share and email attachment share.
- Employee tool assignment signatures.
