package com.idt.steelworks;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class InventoryDb extends SQLiteOpenHelper {
    public InventoryDb(Context c){super(c,"idt_inventory.db",null,1);}
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,emp_id TEXT,id_photo TEXT)");
        db.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,item_no TEXT UNIQUE NOT NULL,make TEXT,model TEXT,type TEXT,description TEXT,serial TEXT,price REAL,employee_id INTEGER,item_photo TEXT,employee_sig TEXT,supervisor_sig TEXT,created INTEGER)");
    }
    public void onUpgrade(SQLiteDatabase db,int o,int n){}
    public long addEmployee(String name,String empId,String photo){ContentValues v=new ContentValues();v.put("name",name);v.put("emp_id",empId);v.put("id_photo",photo);return getWritableDatabase().insert("employees",null,v);}
    public long addItem(ContentValues v){return getWritableDatabase().insertOrThrow("items",null,v);}
    public Cursor employees(String q){String x="%"+(q==null?"":q.trim())+"%";return getReadableDatabase().rawQuery("SELECT * FROM employees WHERE name LIKE ? OR emp_id LIKE ? ORDER BY name",new String[]{x,x});}
    public Cursor items(String q){String x="%"+(q==null?"":q.trim())+"%";return getReadableDatabase().rawQuery("SELECT i.*,e.name ename,e.emp_id eid,e.id_photo ephoto FROM items i LEFT JOIN employees e ON i.employee_id=e.id WHERE i.item_no LIKE ? OR i.make LIKE ? OR i.model LIKE ? OR i.serial LIKE ? OR COALESCE(e.name,'') LIKE ? ORDER BY i.item_no",new String[]{x,x,x,x,x});}
    public Cursor employee(long id){return getReadableDatabase().rawQuery("SELECT * FROM employees WHERE id=?",new String[]{String.valueOf(id)});}
    public Cursor item(long id){return getReadableDatabase().rawQuery("SELECT i.*,e.name ename,e.emp_id eid,e.id_photo ephoto FROM items i LEFT JOIN employees e ON i.employee_id=e.id WHERE i.id=?",new String[]{String.valueOf(id)});}
    public Cursor itemsForEmployee(long id){return getReadableDatabase().rawQuery("SELECT i.*,e.name ename,e.emp_id eid,e.id_photo ephoto FROM items i LEFT JOIN employees e ON i.employee_id=e.id WHERE i.employee_id=? ORDER BY i.item_no",new String[]{String.valueOf(id)});}
    public double totalValue(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(price),0) FROM items",null);c.moveToFirst();double x=c.getDouble(0);c.close();return x;}
    public int countItems(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    public int countAssigned(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items WHERE employee_id IS NOT NULL",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    public Cursor typeTotals(){return getReadableDatabase().rawQuery("SELECT COALESCE(NULLIF(type,''),'Other') t,COUNT(*) c,COALESCE(SUM(price),0) v FROM items GROUP BY t ORDER BY v DESC",null);}
}
