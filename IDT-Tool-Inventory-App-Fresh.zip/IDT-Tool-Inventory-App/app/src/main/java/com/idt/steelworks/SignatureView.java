package com.idt.steelworks;
import android.content.*;import android.graphics.*;import android.view.*;import java.util.*;
public class SignatureView extends View{
 private Paint p=new Paint(3); private Path path=new Path(); private ArrayList<Path> paths=new ArrayList<>(); private boolean locked=false;
 public SignatureView(Context c){super(c);p.setColor(Color.BLACK);p.setStrokeWidth(5);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);setBackgroundColor(Color.WHITE);}
 public void setLocked(boolean b){locked=b;invalidate();}
 public boolean isLocked(){return locked;}
 public void clearSig(){if(!locked){paths.clear();path.reset();invalidate();}}
 protected void onDraw(Canvas c){super.onDraw(c);for(Path x:paths)c.drawPath(x,p);c.drawPath(path,p);if(locked){p.setColor(Color.rgb(124,255,0));p.setTextSize(28);p.setStyle(Paint.Style.FILL);c.drawText("LOCKED",getWidth()-120,getHeight()-15,p);p.setStyle(Paint.Style.STROKE);p.setColor(Color.BLACK);}}
 public boolean onTouchEvent(android.view.MotionEvent e){if(locked)return true;float x=e.getX(),y=e.getY();switch(e.getAction()){case MotionEvent.ACTION_DOWN:path=new Path();path.moveTo(x,y);invalidate();return true;case MotionEvent.ACTION_MOVE:path.lineTo(x,y);invalidate();return true;case MotionEvent.ACTION_UP:paths.add(path);invalidate();return true;}return true;}
 public Bitmap bitmap(){Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);for(Path x:paths)c.drawPath(x,p);return b;}
}
