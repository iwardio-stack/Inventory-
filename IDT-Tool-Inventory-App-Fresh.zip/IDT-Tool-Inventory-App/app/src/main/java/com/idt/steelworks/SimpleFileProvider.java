package com.idt.steelworks;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SimpleFileProvider extends ContentProvider {
    public static final String AUTHORITY = "com.idt.steelworks.inventory.fileprovider";
    @Override public boolean onCreate(){ return true; }
    @Override public String getType(Uri uri){ return "application/pdf"; }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
        File f=new File(getContext().getCacheDir(),uri.getPath().replaceFirst("^/",""));
        int flags = ParcelFileDescriptor.MODE_READ_ONLY; if(mode.contains("w")) flags = ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE; return ParcelFileDescriptor.open(f,flags);
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){
        File f=new File(getContext().getCacheDir(),uri.getPath().replaceFirst("^/",""));
        MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});
        c.addRow(new Object[]{f.getName(),f.length()}); return c;
    }
    @Override public int delete(Uri u,String s,String[] a){return 0;}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
    @Override public Uri insert(Uri u,ContentValues v){return null;}
}
